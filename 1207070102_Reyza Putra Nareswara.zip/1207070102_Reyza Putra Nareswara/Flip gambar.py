# Import library
import numpy as np
import imageio.v2 as imageio
import matplotlib.pyplot as plt

# Membuat variabel untuk membaca gambar dengan library imageio.v2
img = imageio.imread("OptimusP.jpg")

# Melihat resolusi dan tipe dari gambar
img_height = img.shape[0] # Variabel berisi tinggi gambar
img_width = img.shape[1] # Variabel berisi lebar gambar
img_channel = img.shape[2] # Variabel berisi band gambar
img_type = img.dtype # Variabel berisi tipe gambar

# Membuat variabel untuk flip horizontal dan vertical dengan resolusi dan tipe yang sama dengan gambar
img_flip_horizontal = np.zeros(img.shape, img_type)
img_flip_vertical = np.zeros(img.shape, img_type)

# Membalik gambar secara horizontal
for y in range(0, img_height):
    for x in range(0, img_width):
        for c in range(0, img_channel):
            img_flip_horizontal[y][x][c] = img[y][img_width-1-x][c] #Pembalikan gambar secara horizontal

# Membalik gambar secara vertikal
for y in range(0, img_height):
    for x in range(0, img_width):
        for c in range(0, img_channel):
            img_flip_vertical[y][x][c] = img[img_height-1-y][x][c] #Pembalikan gambar secara vertikal

# Menampilkan gambar menggunakan matplotlib
plt.imshow(img) # Menampilkan gambar asli
plt.title("Gambar original")
plt.show()
plt.imshow(img_flip_horizontal) # Menampilkan gambar yang sudah dibalik horizontal
plt.title("Flip Horizontal")
plt.show()
plt.imshow(img_flip_vertical) # Menampilkan gambar yang sudah dibalik vertikal
plt.title("Flip Vertical")
plt.show()